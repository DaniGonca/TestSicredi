package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import suporte.Web;

public class PageObjects extends BasePage {

    public PageObjects(WebDriver navegador) {
        super(navegador);
    }

    public PageObjects() {
        super();
    }

    public void acoes(){

        // Validação de inserção de valores - caminho feliz

        //Campo - Qual o valor que você quer aplicar
        navegador.findElement(By.id("valorAplicar")).sendKeys("RS 20000,00");

        //Campo - Quanto você quer poupar todo mês
        navegador.findElement(By.id("valorInvestir")).sendKeys("RS 100,00");

        //Campo - Por quanto tempo você quer poupar
        navegador.findElement(By.id("tempo")).sendKeys("12");

        // Clicando no simulador
        navegador.findElement(By.xpath("//*[@id=\"formInvestimento\"]/div[5]/ul/li[2]/button")).click();


    }
}
