package tests;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.After;
import org.junit.rules.TestName;
import org.openqa.selenium.*;
//import suporte.Generator;
//import suporte.Screenshot;
import pages.PageObjects;
import suporte.Generator;
import suporte.Screenshot;
import suporte.Web;


//@RunWith(DataDrivenTestRunner.class)
//@DataLoader(filePaths = "InformacoesUsuarioTestData.csv")
public class InformacoesUsuarioTests {
    private WebDriver navegador;
    private PageObjects page;

    @Rule
    public TestName test = new TestName();

    @Before
    public void setUp() {

        navegador = Web.createChrome();
        page = new PageObjects(navegador);

    }

    @Test
    public void testPesquisaUsuario(){

              //gerar evidencias de login
        String screenshotArquivo = "C:/Users/gonca/OneDrive/Documentos/novaAutomacao" + Generator.dataHoraParaArquivo() + test.getMethodName() + ".png";
        Screenshot.tirar(navegador, screenshotArquivo);
        page.acoes();

    }

    //@Test
   // public void validarCarrinho(){

        //navegador.findElement(By.)
    //}

    @After
    public void tearDown() {
        // Fechar o navegador
        navegador.quit();
    }
}