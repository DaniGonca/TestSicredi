package tests;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.After;
import org.junit.rules.TestName;
import org.openqa.selenium.*;
//import suporte.Generator;
//import suporte.Screenshot;
import pages.PageObjects;
import suporte.Generator;
import suporte.Screenshot;
import suporte.Web;
import pages.Logout;
import pages.Logar;

//@RunWith(DataDrivenTestRunner.class)
//@DataLoader(filePaths = "InformacoesUsuarioTestData.csv")
public class InformacoesUsuarioTests {
    private WebDriver navegador;
    private Logout logout;
    private Logar login;
    private PageObjects page;

    @Rule
    public TestName test = new TestName();

    @Before
    public void setUp() {

        navegador = Web.createChrome();
        logout = new Logout(navegador);
        login = new Logar(navegador);
        page = new PageObjects(navegador);
        // validar um link que possui a class "ALREADY REGISTERED"
        //WebElement formularioLogin = navegador.findElement(By.id("authentication"));
    }

    @Test
    public void testPesquisaUsuario(){

        login.realizarLogin();
        //gerar evidencias de login
        String screenshotArquivo = "/Users/Eduardo/Downloads/" + Generator.dataHoraParaArquivo() + test.getMethodName() + ".png";
        Screenshot.tirar(navegador, screenshotArquivo);
        page.acoes();
        logout.deslogar();

    }

    //@Test
    public void validarCarrinho(){

        //navegador.findElement(By.)
    }

    @After
    public void tearDown() {
        // Fechar o navegador
        navegador.quit();
    }
}