package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import tests.InformacoesUsuarioTests;

public class LoginFormPage extends BasePage {

    public LoginFormPage(WebDriver navegador) {
        super(navegador);
    }

    public LoginFormPage digitarLogin(String login) {
        navegador.findElement(By.id("login")).findElement(By.name("login")).sendKeys(login);

        return this;
    }

    public LoginFormPage digitarSenha(String password) {
        navegador.findElement(By.id("login")).findElement(By.name("passwd")).sendKeys(password);

        return this;
    }

    public SecretaPage clicarSignIn() {
        navegador.findElement(By.linkText("Sign in")).click();

        return new SecretaPage(navegador);
    }

    public SecretaPage fazerLogin(String login, String senha) {
        return digitarLogin(login)
                .digitarSenha(senha)
                .clicarSignIn();
    }

    public SecretaPage testPesquisaUsuario(){
        navegador.findElement(By.linkText("ORDER HISTORY AND DETAILS")).click();
        return new SecretaPage(navegador);
    }

    public SecretaPage realizarLogin(WebDriver navegador){
        // Clicar no link que possui o texto "Sign in"
        navegador.findElement(By.linkText("Sign in")).click();

        // Identificando o formulário de Login
        WebElement formularioSignInBox = navegador.findElement(By.id("authentication"));

        // Digitar no campo com name "login" que está dentro do formulário de id "signinbox" o texto "julio0001"
        formularioSignInBox.findElement(By.name("email")).sendKeys("eduardo.machado91@hotmail.com");

        // Digitar no campo com name "password" que está dentro do formulário de id "signinbox" o texto "Bobfilho20"
        formularioSignInBox.findElement(By.name("passwd")).sendKeys("Bobfilho20");

        // Clicar no link com o texto "SIGN IN"
        navegador.findElement(By.name("SubmitLogin")).click();
        return new SecretaPage(navegador);
    }


}