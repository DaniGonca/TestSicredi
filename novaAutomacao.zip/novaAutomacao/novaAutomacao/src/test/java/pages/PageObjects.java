package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import suporte.Web;

public class PageObjects extends BasePage {

    public PageObjects(WebDriver navegador) {
        super(navegador);
    }

    public PageObjects() {
        super();
    }

    public void acoes(){


        // Clicar em um link que poossui o texto "ORDER HISTORY AND DETAILS"
        navegador.findElement(By.linkText("ORDER HISTORY AND DETAILS")).click();

        //Pesquisar item
        navegador.findElement(By.id("history")).sendKeys("T_SHIRT");

        navegador.findElement(By.name("submit_search")).click();

        //validando os resultados da pesquisa
        WebElement mensagem = navegador.findElement(By.id("search"));

        //selecionando um produto
        navegador.findElement(By.linkText("Printed Chiffon Dress")).click();

        //adicionando o produto no carrinho
        navegador.findElement(By.name("Submit")).click();

        //validando o produto no carrinho
        WebElement mensagemSucesso = navegador.findElement(By.className("cross"));

        navegador.findElement(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a/span")).click();

        navegador.findElement(By.id("order"));

        navegador.findElement(By.xpath("//*[@id=\"center_column\"]/p[2]/a[1]/span")).click();

        navegador.findElement(By.id("order"));

        navegador.findElement(By.xpath("//*[@id=\"center_column\"]/form/p/button/span")).click();

        navegador.findElement((By.id("cgv"))).click();

        navegador.findElement(By.xpath("//*[@id=\"header\"]/div[3]/div/div/div[3]/div/a/b")).click();

        navegador.findElement(By.xpath("//*[@id=\"header\"]/div[3]/div/div/div[3]/div/a"));

        navegador.findElement(By.xpath("//*[@id=\"total_price\"]"));

    }
}
