package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import pages.BasePage;
import suporte.Web;

public class Logar extends BasePage{

    public Logar(WebDriver navegador) {
        super(navegador);
    }

    public Logar() {
        super();
    }

    public void realizarLogin() {
        // Clicar no link que possui o texto "Sign in"
        navegador.findElement(By.linkText("Sign in")).click();

        // Identificando o formulário de Login
        WebElement formularioSignInBox = navegador.findElement(By.id("authentication"));

        // Digitar no campo com name "login" que está dentro do formulário de id "signinbox" o texto "julio0001"
        formularioSignInBox.findElement(By.name("email")).sendKeys("eduardo.machado91@hotmail.com");

        // Digitar no campo com name "password" que está dentro do formulário de id "signinbox" o texto "Bobfilho20"
        formularioSignInBox.findElement(By.name("passwd")).sendKeys("Bobfilho20");

        // Clicar no link com o texto "SIGN IN"
        navegador.findElement(By.name("SubmitLogin")).click();
    }
}