package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import suporte.Web;
import pages.BasePage;

public class Logout extends BasePage {

    public Logout(WebDriver navegador) {
        super(navegador);
    }

    public Logout() {
        super();
    }


    public void deslogar(){


        navegador.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[2]/a")).click();


    }
}